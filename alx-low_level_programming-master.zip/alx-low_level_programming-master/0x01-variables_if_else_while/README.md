Practicing conditional statements on C programming language 
