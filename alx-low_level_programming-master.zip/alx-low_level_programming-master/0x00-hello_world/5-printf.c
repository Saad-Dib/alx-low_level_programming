#include <stdio.h>
/**
 * main- prints a string followed by a new line
 * Return: 0
 */
int main(void)
{
printf("with proper grammar, but the outcome is a piece of art,\n");
return (0);
}
