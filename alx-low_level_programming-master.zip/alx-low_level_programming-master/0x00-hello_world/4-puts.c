#include <stdio.h>
/**
 *main- A program that uses puts to print a string
 *Return: ends with 0
 */
int main(void)
{
puts("\"Programming is like building a multilingual puzzle");
return (0);
}
